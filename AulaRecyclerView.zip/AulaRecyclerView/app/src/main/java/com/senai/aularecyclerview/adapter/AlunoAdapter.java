package com.senai.aularecyclerview.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.senai.aularecyclerview.R;
import com.senai.aularecyclerview.model.Aluno;

import java.util.List;

public class AlunoAdapter  extends RecyclerView.Adapter<AlunoAdapter.AlunoViewHolder> {

    private List<Aluno> ListaAlunos;


    public  AlunoAdapter(List<Aluno> ListaAlunos){
        this.ListaAlunos = ListaAlunos;
    }


    @NonNull
    @Override
    public AlunoAdapter.AlunoViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                                           int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_aluno,
                parent, false);

        return new AlunoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AlunoAdapter.AlunoViewHolder holder, int position) {

        Aluno aluno = ListaAlunos.get(position);

        holder.txtNome.setText(aluno.getNome());
        holder.txtCurso.setText(aluno.getCurso());


    }

    @Override
    public int getItemCount() {
        return ListaAlunos.size();
    }

    public class AlunoViewHolder extends RecyclerView.ViewHolder {

        TextView txtNome;

        TextView txtCurso;


        public AlunoViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNome = itemView.findViewById(R.id.txtNome);
            txtCurso = itemView.findViewById(R.id.txtCurso);
        }
    }
}
