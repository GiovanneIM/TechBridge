package com.senai.aularecyclerview;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.senai.aularecyclerview.adapter.AlunoAdapter;
import com.senai.aularecyclerview.model.Aluno;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AlunoAdapter alunoAdapter;
    private List<Aluno> ListaAlunos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerAlunos);

        ListaAlunos = new ArrayList<>();

        ListaAlunos.add(new Aluno("Gabriel Queiroz", "Desenvolvimento de Sistemas"));
        ListaAlunos.add(new Aluno("Arthur Polo", "ADS"));
        ListaAlunos.add(new Aluno("Daniel Miranda", "Marketing"));
        ListaAlunos.add(new Aluno("Murilo Brandalezi", "Sociologia"));

        alunoAdapter = new AlunoAdapter(ListaAlunos);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(alunoAdapter);
    }
}