package com.senai.aularecyclerview.model;

public class Aluno {

    private String nome;
    private String curso;
    private int imagem;

    public Aluno(String nome, String curso){
        this.nome = nome;
        this.curso = curso;
    }


    public String getNome(){
        return nome;
    }

    public String getCurso(){
    return curso;
    }
}
